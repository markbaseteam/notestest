tags: #🗃/🟩 
aliases: 
ref: https://twitter.com/JeffBooth



---
## Highlights
- It is impossible over the longer term for laws to protect a population from manipulated money.... when the laws are influenced by the people that benefit most from that manipulation. 
  Only an emergent parallel system- outside of that control could solve that paradox. 

