tags: #🗃/🟨 
aliases: 
ref: 


---
# The Case Against Bitcoin

## Metadata
- Author: [[Michael W. Green]]
- Full Title: The Case Against Bitcoin
- URL: https://bariweiss.substack.com/p/the-case-against-bitcoin

## Highlights
- In other words: the nation-state is necessarily fighting a rear-guard, anti-progress agenda and the individual — assuming they are technologically savvy and wealthy — is necessarily unbound as a [“sovereign individual”](https://www.amazon.com/Sovereign-Individual-Mastering-Transition-Information/dp/0684832720/ref=sr_1_1?dchild=1&gclid=Cj0KCQjws-OEBhCkARIsAPhOkIbeYM7sZpIhW5wO3zn9jp3j-qVEUyjcvFVgmEOKGRD7AY7Rhzw9ykgaAtaiEALw_wcB&hvadid=241620414457&hvdev=c&hvlocphy=9032119&hvnetw=g&hvqmt=e&hvrand=12759530617725258810&hvtargid=kwd-59452726&hydadcr=22564_10354992&keywords=the+sovereign+individual&qid=1620700844&sr=8-1) (a bit of a bible to the Bitcoiners). By stripping the provision of “money” from the state, Bitcoin has become the ultimate expression of freedom from government interference. Based on this belief system, Bitcoin must, by definition, be a social good. ([View Highlight](https://read.readwise.io/read/01gp95bwsstd0pg16j9hejvhs9))
- Munger, in contrast, is expressing contrasting beliefs about human nature and about the nature of politics and markets. Namely, that our inevitable flaws, including our lack of perfect foresight, require guardrails to reduce the risk of unintended consequences, like, for example, speculation in “low-risk” mortgages that drove a global financial crisis. Without borders, languages, culture and, yes, fiat currency, our civilization can be easily placed at risk. ([View Highlight](https://read.readwise.io/read/01gp95c48edv1ssnw6543s8qt8))
- Bitcoin has created unique vulnerabilities by growing rapidly in an environment without a regulatory regime prepared for it. What’s worse is that its proponents are more than willing to conceal the facts to promote its success. For this reason alone we should be skeptical. ([View Highlight](https://read.readwise.io/read/01gp95f456rh503w7711bpbvtv))
- Crypto advocates are fun to follow on Twitter, but they won’t tell you the following: ([View Highlight](https://read.readwise.io/read/01gp95greg2wp9kk5v8m3t8ddm))
- 1. Money exists for one purpose: to cancel debt. ([View Highlight](https://read.readwise.io/read/01gp95h82q945tmk9qz8yaf30b))
- In contrast, Bitcoin is a speculative asset that, like all assets, requires systems of law and force to protect it. ([View Highlight](https://read.readwise.io/read/01gp95jddypreekhj34sfp6teg))
- 2. I am not an apologist for American hegemony and all the behaviors it has enabled. But imagine the counterfactual. ([View Highlight](https://read.readwise.io/read/01gp95k225e22btzmbn30c5xcq))
- Over the course of the 20th century, the relative standard of living of those who lived under the protective umbrella of Pax Americana exploded relative to those living under the competing Soviet or Chinese systems. While techno-optimists will suggest that the counterfactual is utopian, the evidence on the ground is far darker. ([View Highlight](https://read.readwise.io/read/01gp95m9ane386jd6tvq3dxf1q))
- 3. China, Iran and Russia are playing the dominant role in the world of cryptocurrency. ([View Highlight](https://read.readwise.io/read/01gp95menj2a6y23f0w54vev9h))
- Bitcoin mining — the process of record keeping for the “immutable” chain of record on which the Bitcoin network depends — is dominated by entities in countries with the stated objective to harm the interests of the United States. ([View Highlight](https://read.readwise.io/read/01gp95nhfxeh99qbzh429dr4k8))
- This is not a decentralized system. It is centralized in the countries that seek our destruction. ([View Highlight](https://read.readwise.io/read/01gp95nyevdm5e9ahqwjnh02fq))
- **4. When Peter Thiel [floated the idea](https://www.bloomberg.com/news/articles/2021-04-07/peter-thiel-calls-bitcoin-a-chinese-financial-weapon-at-virtual-roundtable) a few weeks ago that perhaps “Bitcoin should also be thought of in part as a Chinese financial weapon against the U.S.,” he wasn’t mincing words**. ([View Highlight](https://read.readwise.io/read/01gp95pats0m957a8sycq0sysg))
- With China having [banned](https://openscholarship.wustl.edu/cgi/viewcontent.cgi?article=1684&context=law_globalstudies) domestic ownership and usage of Bitcoin, while dominating Bitcoin production and encouraging foreign speculation in the asset, this seems a reasonable avenue of exploration. ([View Highlight](https://read.readwise.io/read/01gp95pqrq7hz90pjcajx92bsx))
- **5. Those bullish on crypto love to point out that there is more criminal activity occurring in U.S. dollars than in Bitcoin.** Given the dominance of the dollar in economic activity, this should surprise absolutely no one. What they leave out is that roughly 40% of crypto transactions are used for illicit activity. ([View Highlight](https://read.readwise.io/read/01gp95qk8ngf964sn0f3hasexr))
- 6. Bitcoin mining is remarkably energy intensive. ([View Highlight](https://read.readwise.io/read/01gp95rnydm0qnpg96jqez8t0m))
- **7. Bitcoin marketing is designed to mislead,** with an expressed refusal to report anything negative — a strategy frequently used to great effect in Silicon Valley to promote entities of dubious value like WeWork. ([View Highlight](https://read.readwise.io/read/01gp95twwxqzrg9b8wa4w3f0nv))
- **8. Just because the price of something is going up does not mean there it has an underlying value.** Nothing makes that case clearer than the story of Dogecoin, the latest crypto sensation. ([View Highlight](https://read.readwise.io/read/01gp95vqfcfq5prwawrj8b6m4z))
- 9. While arguing for a utopian future, Bitcoin proponents embrace the time-tested methods of exploiting societal fear to drive adoption. ([View Highlight](https://read.readwise.io/read/01gp95wa85gxwx97vr2ttv3r5c))
- **10. The final lie is the most important: “Bitcoin is unstoppable.”** Over a year ago, some talented technologists [proposed a mechanism](https://joekelly100.medium.com/how-to-kill-bitcoin-part-1-is-bitcoin-unstoppable-code-7a1b366f65ee) by which a state actor could disable the Bitcoin network at remarkably low cost. ([View Highlight](https://read.readwise.io/read/01gp960crc2726zx64k9ekq7mx))
- Why are you unaware of this? Because the objective of Bitcoin promoters is to drive speculative activity into Bitcoin rather than offer you an informed choice. ([View Highlight](https://read.readwise.io/read/01gp960fqgfmke26vrwzjf8k7h))
