tags: #🗃/🟩 
aliases: 
ref: 
# The Misuse of Mathematics in Economics

## Metadata
- Author: [[LARS P. SYLL]]
- Full Title: The Misuse of Mathematics in Economics
- URL: https://larspsyll.wordpress.com/2022/12/08/the-misuse-of-mathematics-in-economics/

---
## Highlights
- One reason to use math is that it is easy to use math to trick people. Often, if you make your assump-tions in plain English, they will sound ridiculous. But if you couch them in terms of equations, integrals, and matrices, they will appear more sophisticated, and the unrealism of the assumptions may not be obvious, even to people with Ph.D.’s from places like Harvard and Stanford, or to editors at top theory journals such as Econometrica … ([View Highlight](https://read.readwise.io/read/01gmse7g5fheerpp2chfnpty5d))
- Given the importance of signaling in all walks of life, and given the power of math, not just to illuminate and to signal, but also to trick, confuse, and bewilder, it thus makes perfect sense that roughly 99% of the core training in an economics Ph.D. is in fact in math rather than economics. ([View Highlight](https://read.readwise.io/read/01gmse848ybwhnbcr1j3ne8hjf))
- Mainstream economists have always wanted to use their hammer, and so have decided to pretend that the world looks like a nail. Pretending that uncertainty can be reduced to risk and that all activities, relations, processes, and events can be adequately converted to pure numbers, have only contributed to making economics irrelevant and powerless when confronting real-world financial crises and economic havoc. ([View Highlight](https://read.readwise.io/read/01gmse9zz11d5hbbxpnt7s7z6v))
- ream economists have always ([View Highlight](https://read.readwise.io/read/01gmse9pz9vqm7ejj0ezfwgk0d))
- (1) **Stop pretending that we have exact and rigorous answers on everything**. ([View Highlight](https://read.readwise.io/read/01gmseakk04gdgc2t5yzvyg3gg))
- (2) **Stop the childish and exaggerated belief in mathematics giving answers to important economic questions**. ([View Highlight](https://read.readwise.io/read/01gmseb2avnk0920vpbxxcbmgk))
- (3) **Stop pretending that there are laws in economics**. ([View Highlight](https://read.readwise.io/read/01gmsec2dw0apr257wvt3mcjj5))
- (4) **Stop treating other social sciences as poor relations.** ([View Highlight](https://read.readwise.io/read/01gmsed8pfgqtaqqnjck9z2qx8))
- (5) **Stop building models and making forecasts of the future based on totally unreal micro-founded macro models with intertemporally optimizing robot-like representative actors equipped with rational expectations.** ([View Highlight](https://read.readwise.io/read/01gmsedq653cbdsn9fhx31tfht))
- Mainstream economic theory today is still in the story-telling business whereby economic theorists create mathematical make-believe analog models of the target system – usually conceived as the real economic system. This mathematical modeling activity is considered useful and essential. To understand and explain relations between different entities in the real economy the predominant strategy is to build mathematical models and make things happen in these ‘analog-economy models’ rather than engineering things happening in real economies. ([View Highlight](https://read.readwise.io/read/01gmsegzphsgrfc2qv34rhrfnn))
- Math cannot establish the truth value of a fact. Never has. Never will. ([View Highlight](https://read.readwise.io/read/01gmtp11knecsee5hgc7saz719))
- If one proposes ‘efficient markets’ or ‘rational expectations’ one also has to support their underlying assumptions. As a rule, none is given, which makes it rather puzzling how things like ‘efficient markets’ and ‘rational expectations’ have become standard modeling assumptions made in much of modern macroeconomics. The reason for this sad state of ‘modern’ economics is that economists often mistake mathematical beauty for truth. ([View Highlight](https://read.readwise.io/read/01gmtp2evs2xnr4n3wrts3eh0z))
