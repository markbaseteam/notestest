tags: #🗃/🟨 
aliases: 
ref:

---
# Young Generations Are Now Poorer Than Their Parents And It's Changing Our Economies

![rw-book-cover](https://i.ytimg.com/vi/PkJlTKUaF3Q/mqdefault.jpg)

## Metadata
- Author: [[Economics Explained]]
- Full Title: Young Generations Are Now Poorer Than Their Parents And It's Changing Our Economies
- URL: https://youtube.com/watch?v=PkJlTKUaF3Q

## Highlights
- > 當老人種樹時，社會就會變得偉大，因為他們知道自己永遠不會坐在樹蔭下。這句希臘諺語來自遠在現代經濟問題或經濟研究本身之前的時代，今天看來，它和幾千年前一樣正確。
  “A society grows great when old men plant trees in whose shade they shall never sit.” a greek proverb from a time well before the problems of our modern economies or the study of economics itself is as true today as it was thousands of years ago ([Time 0:00:00](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b4783b096ba600099fd533))
- > 英國政治家、人口統計學家和作家大衛-維爾茨勛爵（Lord David Willets）認為，事實可能恰恰相反，在一個民主制度中，成為較大群體的一部分實際上是可取的，因為它使該群體在代際問題上有更多的投票權，在市場上有更大的影響力。
  lord david willets a british politician demographer and author suggests that the opposite may be true and that in a democratic system being part of a larger cohort is actually preferable because it gives that group more voting power on generational issues and more sway in marketplaces ([Time 0:02:04](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b478c05066cf0009250c69))
- > 在過去的半個世紀裡，在大多數發達經濟體中很容易看到這種趨勢，以我自己的家鄉澳大利亞為例，2019年的聯邦選舉或多或少是由一項政策決定決定的，該政策將降低澳大利亞退休賬戶的稅收效益，主張保持有利的稅收結構的政黨最終贏得了勝利，這主要是由於澳大利亞的老年選民。
  it is easy to see this trend throughout the past half century in most advanced economies in my own home of australia for example the 2019 federal election was more or less decided by a policy decision that would reduce the tax effectiveness of australian retirement accounts the party that advocated for keeping the favorable tax structure ended up winning primarily thanks to older australian voters ([Time 0:03:36](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b47912096ba600099fdfa4))
- > 2017年英國選舉研究發現，隨著時間的推移，保守黨的選票已經從以富人和工人階級劃分，轉為以年輕人和老年人劃分。
  a 2017 british election study found that over time votes for conservative parties have shifted from being divided by rich and working class to being divided by young and old ([Time 0:04:05](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b4791f396d7e000938bf70))
- > 較高的利率實際上有助於他們將錢存入每年支付10％利息的賬戶，真正加快了儲蓄目標的實現。 較高的利率也確保房價不會太高，因為還款會變得無法負擔。
  higher interest rates actually kind of helped them saving money for a deposit in an account that pays 10 interest per year really accelerates that savings goal higher interest rates also ensure that house prices never got too high because the repayments would just become unaffordable ([Time 0:08:04](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b479e25066cf0009250c6b))
- > 如果還款額保持不變，1985年買房的人可以在5年內而不是30年內還清房款。
  if the repayments were kept equal the person buying the home in 1985 could have it paid off in five years rather than 30 years ([Time 0:08:57](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b47a34396d7e000938bf71))
- > 世界上的每一個經濟都或好或壞地集中在大型經濟活動中心，也就是普通人所說的城市，如果這些城市的房地產變得過於昂貴，那麼工人就不可能在那裡工作，因為他們越來越多的收入將用於支付租金，在短期內這可以通過提高工資來抵消，但這些中心實際上只是在經營 房東從他們的房產中賺到的錢不可能再投入到公司的發展中，也不可能花在維持這些企業的正常消費上，而是可能花在更多的房產上，進一步推高市場價值，把生產性中心的錢吸走，塞進非生產性資產中。
  every economy in the world is still for better or worse focused around large centres of economic activity what a regular person might call a city if the real estate in these cities becomes too expensive then it becomes infeasible for workers to hold down jobs there because more and more of their income will just go to paying rent in the short term this can be offset by higher wages but then these centres are really just operating for the benefit of the landlords that are lucky enough to own property there the money that landlords make from their properties are unlikely to be reinvested into company growth or spent on regular consumer consumption that keeps these businesses in business it is likely to be spent on more property further driving up market values and the amount of money that gets sucked out of productive centres to be shoved into unproductive assets ([Time 0:10:04](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b47a995066cf0009250c6c))
- > 財富集中在某一代人身上，會對整個經濟產生非常實際的影響，而且隨著人口不斷老化，這些影響只會越來越明顯。
  the concentration of wealth in a particular generation is something that can have very real consequences for entire economies and these effects are only going to get more pronounced as populations continue to age ([Time 0:11:26](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b47ac55066cf0009250c6d))
- > 大多數人在他們自己相當老的時候才會收到父母過世的錢，往往是接近職業生涯的尾聲或開始退休，如果錢傳給他們，他們很可能只是用它來資助自己的退休生活，然後只是把剩下的錢傳給自己年老的孩子。 錢集中在老年人手中意味著年輕人獲得的機會將減少，以做所有他們為建立一個正常的經濟所做的事。
  most people don't receive money from their parents passing until they are pretty old themselves often approaching the end of their careers or starting retirement if the money gets handed down to them they are likely just going to use it to fund their own retirements and then just hand down whatever's left to their own elderly children money pooling in the hands of older people means less opportunity will be afforded to younger people to do all the things that they do to build a functioning economy ([Time 0:12:54](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b47b14bac9ae000913c9dc))
- > 經濟繁榮也是潮人享有的東西，但不一定在他們的控制範圍內。從歷史標準來看，20世紀的後半期是非常和平的，世界也向國際貿易開放，增長被以化石燃料形式存在的大量廉價能源所推動，這是一個發財的好時機，人們做到了，這可能是拼圖的最後一塊。
  economic prosperity was also something that boomers enjoyed that wasn't necessarily within their control the last half of the 20th century by historical standards was very peaceful the world also opened up to international trade and growth was put into overdrive by an abundance of cheap energy in the form of fossil fuels it was a great time to make a fortune and people did which is probably the final piece of the puzzle ([Time 0:14:47](https://annotate.tv/watch/62b477d1096ba600099fd532?annotationId=62b47b80bac9ae000913c9dd))
