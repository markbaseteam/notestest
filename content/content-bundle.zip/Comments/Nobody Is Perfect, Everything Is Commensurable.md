tags: #🗃/🟨 
aliases: 
ref: 


---
# Nobody Is Perfect, Everything Is Commensurable

## Metadata
- Author: [[Scott Alexander]]
- Full Title: Nobody Is Perfect, Everything Is Commensurable
- URL: https://slatestarcodex.com/2014/12/19/nobody-is-perfect-everything-is-commensurable/

## Highlights
- The moral of the story is that if you feel an obligation to give back to the world, participating in activist politics is one of the worst possible ways to do it. Giving even a tiny amount of money to charity is hundreds or even thousands of times more effective than almost any political action you can take. Even if you’re absolutely convinced a certain political issue is the most important thing in the world, you’ll effect more change by donating money to nonprofits lobbying about it than you will be reblogging anything. ([View Highlight](https://read.readwise.io/read/01gp05aqxwgxrxwws44khzzpgw))
- Anybody saying that people who want to do good need to spread their political cause is about as credible as a televangelist saying that people who want to do good need to give them money to buy a new headquarters. ([View Highlight](https://read.readwise.io/read/01gp05hkk120j71dhnr703gf7s))
- our universal obsession with politics, race, and gender incites people to make convincing arguments that taking and spreading the right position on those issues is the one true test of a decent human being. ([View Highlight](https://read.readwise.io/read/01gp05pcx29np33nmdn4j0hcse))
- I, on the other hand, would prefer to call that “not being perfect”. I would prefer to say that if you feel like you will live in anxiety and self-loathing until you have given a certain amount of money to charity, you should make that certain amount ten percent. ([View Highlight](https://read.readwise.io/read/01gp05xnbpsbvb26wajbfv6bmj))
- Why ten percent?
  It’s ten percent because that’s the standard decreed by [Giving What We Can](https://www.givingwhatwecan.org/) and the effective altruist community. Why should we believe their standard? I think we should believe it because if we reject it in favor of “No, you are a bad person unless you give *all* of it,” then everyone will just sit around feeling very guilty and doing nothing. But if we very clearly say “You have discharged your moral duty if you give ten percent or more,” then many people will give ten percent or more. The most important thing is having a Schelling point, and ten percent is nice, round, [divinely ordained](http://en.wikipedia.org/wiki/Tithe), and – crucially – the Schelling point upon which we have already settled. It is an *active* Schelling point. ([View Highlight](https://read.readwise.io/read/01gp05yvjkegaw06a5d5pnfsfx))
- It’s ten percent because [definitions were made for Man, not Man for definitions](https://slatestarcodex.com/2014/11/21/the-categories-were-made-for-man-not-man-for-the-categories/), and if we define “good person” in a way such that everyone is sitting around miserable because they can’t reach an unobtainable standard, we are stupid definition-makers. If we are smart definition-makers, we will define it in whichever way which makes it the most effective tool to convince people to give at least that much. ([View Highlight](https://read.readwise.io/read/01gp062ne3w95c4z2mw32wn44v))
- If, [as I’ve argued](https://slatestarcodex.com/2014/07/30/meditations-on-moloch/), the reason we can’t solve world poverty and disease and so on is the capture of our financial resources by the undirected dance of incentives, then what better way to fight back than by saying “Thanks but no thanks, I’m taking this abstract representation of my resources and using it *exactly* how I think it should most be used”? ([View Highlight](https://read.readwise.io/read/01gp06aparzbbb9tpbzq4ry98m))
- Nobody is perfect. This gives us license not to be perfect either. Instead of aiming for an impossible goal, falling short, and not doing anything at all, we set an arbitrary but achievable goal designed to encourage the most people to do as much as possible. That goal is ten percent. ([View Highlight](https://read.readwise.io/read/01gp06f75v6qmdjg17b36enckw))
