tags: #🗃/🟨
aliases: 

---
# The Current Crisis of Masculinity

![rw-book-cover](https://i.ytimg.com/vi/vIt9SgruM9s/mqdefault.jpg)

## Metadata
- Author: [[Jordan B Peterson]]
- Full Title: The Current Crisis of Masculinity
- URL: https://youtube.com/watch?v=vIt9SgruM9s

## Highlights
- > 人們承受著生存的負擔，你知道這是生命的內在組成部分，我想在與自然的關係中感到內疚，在與文化的關係中感到內疚，你知道我們很難與自然界和諧相處，自然界也很難與我們和諧相處，在社會方面，我們沒有人是我們可以做到的，這就是後果之一，所以我們有這種內在的感覺，你知道我們身上有一種缺乏，需要得到糾正，不幸的是，這可以被武器化，而且已經被武器化。
  people bear an existential burden you know it's an intrinsic part of life to i suppose to feel guilty in relationship to nature and to feel guilty in relationship to culture you know it's difficult for us to live in harmony with the natural world and for the natural world to live in harmony with us by the way and none of us are all we could be on the social front and one of the consequences and so we we have that sense intrinsically you know that there's a lack in us that needs to be redressed and unfortunately that can be weaponized and has been ([Time 0:00:27](https://annotate.tv/watch/62d815ec5ea5260009a3b1cd?annotationId=62d8161e5ea5260009a3b342))
- > 我們在這個世界上有這樣一種感覺，人類生活在與自然的對立面，我們實際上是一種邪惡的力量，我們的社會結構顯然能夠實施暴行，其本質是壓迫性的父權制，因此，如果你是一個社會中的男性，有這樣的精神，你是驅動你進入世界生活的動力，與貪婪和掠奪有關的自然方面，然後是壓迫和暴行的社會方面。在自然方面是掠奪，在社會方面是壓迫和暴行 就像這樣，如果你有一點良知，因為這種指責對有良知的年輕人傷害最大 那麼你能做的就是把自己閹割掉，那會很滑稽，但這也在發生，所以我想這就是為什麼我認為有危機的原因
  we have this sense in the world that human beings live in antagonism to nature and that we're actually a malevolent force and that our social structures which are clearly capable of the commission of atrocity are fundamentally oppressive patriarchal in their nature and so then if you're a male in a society with that ethos you're the motive force that drives you into the world to live is associated with rapaciousness and despoilation on the natural front and then oppression and atrocity on the social front it's like well then if you're the least bit conscientious because this sort of accusation hurts conscientious young men the most then the best you can do is well let's say castrate yourself how would that be and that would be real comical except that it's also happening so i guess that's why that's why i think there's a crisis ([Time 0:01:19](https://annotate.tv/watch/62d815ec5ea5260009a3b1cd?annotationId=62d816550bd2e900098b6d66))
- > 它指出了將有能力的自信與權力本身的表達分離開來的問題，所以我們可以稱權力為 我將其定義為使用強制力來實現你的目標的意願和能力 現在，如果你是一個傾向於表現權力的人，那麼這看起來是野心和意志的表現 如果你在生活中沒有與任何男性有積極的關係，甚至可能沒有與你自己內部的男性有關係，那麼你就不能區分權力和有能力，即為能力服務的野心
  it points to the problem of dissociating competent confidence from the expression of power per se so we could call power i'll define that as the willingness and ability to use compulsion to attain your aims now if you are someone who has a proclivity to manifest power then that looks like the manifestation of both ambition and will and if you haven't had a positive relationship with anyone masculine in your life and maybe with not even with your own internal masculinity say you can't discriminate between power and competent the ambition that serves competence ([Time 0:05:21](https://annotate.tv/watch/62d815ec5ea5260009a3b1cd?annotationId=62d816e10bd2e900098b6d67))
- > 權力的表達與親密關係不會產生親密關係或關係，它能產生的最好的結果是像暴政和奴隸制的結合，這並不是婚姻制度本身的特點。
  the expression of power with an intimate relationship does not produce intimacy or a relationship the best it can produce produces like a combination of tyranny and slavery and that does not characterize the institution of marriage per se ([Time 0:08:11](https://annotate.tv/watch/62d815ec5ea5260009a3b1cd?annotationId=62d8174e0bd2e900098b6d69))
