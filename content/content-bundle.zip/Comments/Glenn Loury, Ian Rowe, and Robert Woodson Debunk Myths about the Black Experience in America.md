tags: #🗃/🟥️ 
aliases: 

---
# Glenn Loury, Ian Rowe, and Robert Woodson Debunk Myths about the Black Experience in America

![rw-book-cover](https://i.ytimg.com/vi/hIiyIEyUxu8/mqdefault.jpg)

## Metadata
- Author: [[Hoover Institution]]
- Full Title: Glenn Loury, Ian Rowe, and Robert Woodson Debunk Myths about the Black Experience in America
- URL: https://youtube.com/watch?v=hIiyIEyUxu8

## Highlights
- > thomas soul at that 1980 conference quote one of the problems in dealing with programs for blacks is that vast empires can be built on these programs these programs definitely prevent poverty among bureaucrats economists statisticians and others close quote ([Time 0:03:02](https://annotate.tv/watch/62ee9639e0534a0009a253a7?annotationId=62ee9668731171000997b796))
- > i think that we have to consider what the government can do through law and policy and what it cannot do i think that we have largely accomplished what the government can do in terms of creating a level playing field of opportunity between blacks and others equality before the law correct non-discrimination voting rights open equal access but there are things the government cannot do the government cannot make families stay together the government cannot raise children it can't influence a culture that may encourage behaviors that are counterproductive ([Time 0:04:49](https://annotate.tv/watch/62ee9639e0534a0009a253a7?annotationId=62ee96b1731171000997b797))
- > we have to be as obsessed with the success of the black community to understand what are the factors that have driven that level of success as we are seemingly as obsessed with that segment of the black community that has not been successful ([Time 0:10:02](https://annotate.tv/watch/62ee9639e0534a0009a253a7?annotationId=62ee9720731171000997b798))
