tags: #🗃/🟩 
aliases: 
ref: 
https://www.youtube.com/watch?v=9ARgV3meTq8&ab_channel=LexFridman


---
## Highlights
- the way I see it uhis that we have to separate the engineering problem from the humanproblem and just the way if you tookover an internal combustion enginemanufacturer you shouldn't set yourselfthe the goal of building a trulyefficient engine because you'll never dothat uh you have to figure out at somelevel where do we stop takingresponsibility for The Human Condition
  uh and pretending it can be fixed as anengineering solution ([View Highlight](https://read.readwise.io/read/01gn4xn4nyafey0k4200g4k8j0))
- the problem of course isthat this is an Adaptive landscape andwe're talking about the fitness ofvarious strategies and some of thosestrategies for example can be playing tothe desire to learn more or they couldbe playing to the desire to watch peopleget destroyed in real time uh as aresult you have to imagine that lots of
  bad things are fitand if lots of bad things are Fitchanging the rules of what constitutesfit Behavior willyou know you'll get new baddies figuringout a new exploits so I think one of thethings that we've got to realize is thatTwitter probably doesn't have a solution ([View Highlight](https://read.readwise.io/read/01gn4xpvt9rpe90mc6tfxhkjh6))
- I'm cautiouslyoptimistic that we've got a lot ofreally smart people in the roomum when it comes to talking about elon'suh opportunity the new opportunities
  um but I don't want to set ourselves upthat we're trying to solve problems thatcan't be solved I think that's thereally dangerous issue ([View Highlight](https://read.readwise.io/read/01gn4xr8ecze26z2rnvzqh6hke))
