tags: #🗃/🟨 
aliases: 
ref:

---
# The Dangers of Self-Determination

![rw-book-cover](https://i.ytimg.com/vi/ypzrWzq16bo/mqdefault.jpg)

## Metadata
- Author: [[Bishop Robert Barron]]
- Full Title: The Dangers of Self-Determination
- URL: https://youtube.com/watch?v=ypzrWzq16bo

## Highlights
- > 看看電影 聽聽幾乎每首歌 流行文化中的每一個故事 最後都是有人擺脫了傳統的壓迫性影響 或者有人告訴我應該怎麼做，我找到了自己的聲音 所以，我認為這幾乎是文化中的主流主題 特別是在年輕人中 它一直是有吸引力的自主權
  look at the movies listen to almost every song almost every story told in the popular culture ends up with someone shaking off you know the oppressive influence of a tradition or someone telling me what to do and i find my own voice um so yeah i think that's almost the dominant uh motif in the culture especially among young people you know it's always been attractive autonomy sure that's my life it's my decisions and so on but it's a dead end when it's one-sidedly emphasized ([Time 0:05:04](https://annotate.tv/watch/62b714079e3aed0009177294?annotationId=62b7146fb4520a0009745cb9))
- > 問題在於這兩者之間的搖擺不定，而且這種情況經常發生，我對自主性太強了，這是我的生活，這是我的意志，這是我的方式，這導致了麻煩，然後我有時會因此做出反應，一路走到異質性，我把我的生活完全交給了父母或文化或你知道的流行明星或任何東西，這有它自己的消極性。我把我的生活完全交給父母或文化或你知道的流行明星或任何東西，這有它自己的消極性，我們要去的地方是自治，即上帝成為我生命的Nomos，上帝成為我生命的管理者，這實際上肯定了自治和異質中最好的東西。
  the trouble is the oscillation between the two and that happens a lot is i'm so strong on autonomy it's my life it's my will it's my way that leads to trouble and then i can sometimes react from that and go all the way to heteronomy i turn my life completely over to parents or culture or you know pop stars or whatever it is that's got its own negativity where we're trying to go is theonomy which is god becomes the nomos of my life god becomes the governor of my life and that actually affirms what's best in both autonomy and heteronomy ([Time 0:07:31](https://annotate.tv/watch/62b714079e3aed0009177294?annotationId=62b714b9b4520a0009745cba))
- > 看看《出埃及記》是如何談論甩掉壓迫性的異質性的 它是關於一個被極度腐敗的政治和宗教文化所奴役的民族 他們甩掉了他們的鎖鏈 他們逃離了異質性 但有趣的是他們去了哪裡 他們不是簡單地靠自己的力量遊蕩到沙漠裡 而是去了聖山 他們去了聖山，在那裡他們接受了法律，所以是的，他們逃離了壓迫性的異質性，但他們並沒有衝向純粹的自主性，他們所去的實際上是我剛才所說的自主性，在那裡，上帝和上帝的法律成為他們生活的指導原則 是的，這確實是自主性的一切優點都包含在這個故事中，但這並不是一個單 但這不是對自主權的單方面肯定，而是一個從異質性到自主權的過程，我想說的是，如果你想的話，這就成了整本聖經的主要隱喻。
  look how the book of exodus talk about throwing off oppressive heteronomy it's about a people who are enslaved by a deeply corrupt political and religious culture and they throw off their chains they escape from that heteronomy but what's interesting where do they go they don't simply wander on their own steam into the desert rather they go to the sacred mountain where they receive what a law so yes they've escaped from oppressive heteronomy but they haven't lurched toward sheer autonomy what they've gone to in fact is what i just called theonomy where god and god's law becomes the governing principle of their lives yes indeed that's everything great about autonomy is contained in that story but it's not a one-sided affirmation of autonomy it's a journey from heteronomy to theonomy i would say so that becomes the master metaphor if you want for the whole bible ([Time 0:10:05](https://annotate.tv/watch/62b714079e3aed0009177294?annotationId=62b71537b4520a0009745cbb))
- > 擺脫神聖的國王，這不是答案，壓迫性的人類國王當然是，比如法老，你知道，克服那種異質性當然是，但答案不是向自主性搖擺，而是向自主性投降，神成為Nomos，神成為我生活的法律和準則。
  getting rid of the divine king that ain't the answer oppressive human kings sure like pharaoh you know overcoming that kind of heteronomy sure but the answer is not a lurch to autonomy it's a surrender to theonomy god becomes the nomos god becomes the law and norm of my life ([Time 0:15:54](https://annotate.tv/watch/62b714079e3aed0009177294?annotationId=62b716224e34a80009fc6085))
- > 在某種程度上，上帝的法律是超越我的，這是真的，如果你想的話，它是異類，但它不是傳統意義上的異類，它的異類是這樣的，它肯定了我，並帶出了我最好的一面，對，這就是聖經，但這是一個棘手的地方，要找到它，這是一個棘手的精神空間。
  in a way god's law is beyond me that's true it's heteros if you want it's other but it's not other in a conventional way it's other in such a way that it affirms me and brings out the very best in me right that's the bible but that's a tricky place to find that's a tricky spiritual space to move into ([Time 0:18:42](https://annotate.tv/watch/62b714079e3aed0009177294?annotationId=62b716774e34a80009fc6086))
