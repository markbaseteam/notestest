tags: #🗃/🟥️ 
aliases: 
ref: 


---
The 7 Stages of Climate Awareness | Frankly #10
00:00
Nate Hagens:
Good morning, good humans. I have decided to attempt weekly Franklys. Our podcast 
comes out on Wednesday mornings
and we will have weekly, Franklys as long as it doesn't impair my constitution or I
run out of things to say, and I think the latter is pretty unlikely. Today, I would like to give 
a reflection about
climate change, not about the science of climate 
00:30
change, but about the different stages of
awareness when it comes to the issue of global warming and our future. I can't categorize 
that everyone follows this
same sequence, but this sequence of stages is roughly what I've followed in my own life. 
01:00
Nate Hagens:
And I think it's important to attempt to explain why lots of people use the word climate 
change,
but their solutions and their fixes and their hopes and interventions are wildly different. So 
seven stages of climate awareness. Well, there's stage zero, which is that the
human sphere and the environment are not separate. 
01:30
Many, many humans go through life taking that
forest walk to work or getting a fish out of a lake, and it all seems like it's part
of their life. The natural world and the environmental processes
are invisible to people. It's just all their life. Nate Hagens:
Which brings us to stage one, which is a recognition 
1 / 8
02:00
that the human system is embedded in an environment
that has its own ecological processes, creatures, systems, etc. I learned about this at an early 
age for no,
I mean for one reason at least when I saw the American Indian ad with the tear streaming
down his face for litter in the 1970s. But it became relatively apparent to me that
to get the conveniences and stimulation and 
02:30
comfort of modern life, we do things that
have a deleterious impact on the natural world. Nate Hagens:
So, that would be stage one, being aware that there is an environment. Stage two is that we 
recognize that climate
change, that climate itself is a part of the environmental processes on Earth, and that
climate can and does change over time because 
03:00
of influences. And some of this awareness is looking at paleo
data and the science from the past that many of Earth's mass extinctions were due to 
volcanic
pulses of lava basalts from volcanoes that had huge amounts over tens of thousands of
years belching CO2 into the atmosphere, and 
03:30
that dramatically changed the climate. Nate Hagens:
We also had snowball Earths when CO2 got very low. So the third stage is awareness that 
CO2 is
the culprit and the effects we see of floods and wildfires and massive northern forest
loss and polar bears, and all these things are from accelerated warming due to CO2. Nate 
Hagens:
The fourth stage of climate awareness is recognizing 
2 / 8
04:00
that two thirds of the CO2 that we emit every
year comes from the burning of fossil fuels, and that we know that the CO2 and the 
atmosphere
is predominantly from the burning of this ancient carbon because of the isotope difference
relative to pre-industrial times. Nate Hagens:
And so this stage, there is a blame towards 
04:30
fossil fuels, towards fossil fuel companies
because Exxon knew about climate change 40 years ago and suppressed it, etc. And at this 
stage of climate awareness, it's
blaming this part of our system, fossil oil, coal, and natural gas, and we just need to
get rid of that, replace it with something else, and we will solve climate change. 
05:00
Which brings to the fifth stage of climate
awareness, our energy reality. Nate Hagens:
And the fifth stage, which I learned around 20 years ago or longer, is got three components. 
Nate Hagens:
First of all is that we use 100 billion barrel of oil equivalents of coal, natural gas and
oil to power the modern economy. And these equate to around half a trillion
of actual human workers in what they provide 
05:30
in labor and power potential. And that our entire global $90 trillion economy
is completely supported by these labor and power equivalents. They explain the entire 
globally interconnected
system of transport, trade and basically fossil hydrocarbons, especially oil, are the hemoglobin
of modern society. Nate Hagens:
Our wages, our profits, the size of our economy 
3 / 8
06:00
being a thousand times bigger than it was
500 years ago are predominantly due to this giant amount of ancient productivity that
we're adding to our economies. So, that is a big recognition in the fifth
stage of climate awareness, which is followed by the fact that this stuff is a pulse. We are 
drawing down this ancient carbon battery
of Earth millions of times faster than it 
06:30
was sequestered in the past by daily photosynthesis. Our culture is treating this as if it were
interest when we are rapidly drawing down the principle. Nate Hagens:
The underlying decline rate of existing oil fields in the world is approaching 6% a year. So 
to offset that, we have to drill faster
and more and deeper in order to offset what's already depleting. So this is a one time pulse. 
07:00
There's plenty of natural gas left and there's
plenty of lower grade coal left, but oil as the master resource will start to decline
soon. The third part of energy reality is that energy
has different properties and so-called renewable energy is powerful. It's robust. It's the right 
answer to the wrong question. Nate Hagens:
The question that's currently be asked is how can we reduce our emissions by replacing
fossil fuels with renewable energy? 
07:30
And that's not what's happening. We're adding renewable energy to fossil fuels
to grow the economy. And so the gross GDP is growing, but we're
allocating more and more resources to the energy and material sector. And in order to scale 
renewable energy to
a level equivalent, we would have to massively increase the mining of materials like cobalt
and copper and nickel, and we would have to 
4 / 8
08:00
take energy away from the regular economy
and direct it towards this scaling. Nate Hagens:
It's kind of like getting a job that pays you $100,000 a year and you forecast forward
how you're going to spend that $100,000 the next 10 years, but you forget that you owe
the state, local and national government 40% of that in the form of taxes. So the taxes in 
this biophysical situation
are the energy and materials it will take to get to these fanciful net zero scenarios. 
08:30
So this is the fifth stage of climate awareness
is that energy underpins our modern society and we can't just wish it away, nor can we
replace it. Nate Hagens:
And actually we're going to have to do with less total energy in the not too distant future. 
Which brings me to this sixth stage of climate
awareness, which is that climate change is not the problem. It is a symptom of an underlying 
problem that
has spent long in the making of a social species, 
09:00
self-organizing in an economic system around
profits. The profits are tethered 99% to energy consumption,
which is in turn about 80% tethered to fossil hydrocarbons. We live as part of a system, 
and you have
to understand human behavior, both individual and aggregate. Nate Hagens:
Our anthropological background of how we got here today that we as a global system of 
eight
billion of us try to replicate the emotional 
09:30
states of our ancestors in this wildly consumptive
economic system. And this consumption is tethered to energy
and materials and technology, and we have a monetary overlay on all of it, monetary
symbols that represent this reality. And the whole thing is out of control of billionaires
and politicians. No one has control of this system because
of the momentum. 
5 / 8
10:00
So climate change and many other things, biodiversity
loss, overpopulation, plastics, toxicity, one could argue increasing polarization. Nate Hagens:
A lot of these things are downstream of this huge amount of energy growth imperative. 
Which brings me to the seventh stage of climate
awareness, which is if you understand this systemic overview of the human situation and
how we are much like a blind, amoeba slothing 
10:30
forward grabbing low entropy goodies without
a plan, without even thinking about it. This changes substantially the choreography
of how we will solve climate change. First of all, the really bad climate scenarios
are energy blind in they just assume that we will continue to grow at 3% this entire
century, and that there will be enough fossil 
11:00
hydrocarbons available to continue that growth. Nate Hagens:
That's not going to happen. What will likely happen is we will continue
to optimize for growth. We will not optimize for carbon. We will not optimize for biodiversity. We will continue to make choices like Germany
is making right now by importing trainloads 
11:30
of coal and restarting a massive biomass program. They are repealing their environmental 
rules
in the service of energy security as opposed to low carbon energy. And you see as the 
economic pie begins to
shrink around the world, you will see populous leaders like what happened last night in 
Italy
and a couple weeks ago in Sweden, because 
6 / 8
12:00
loss aversion of what people have versus the
past is a very strong motivator for political response. Nate Hagens:
So once you understand this, this seventh stage of climate awareness is we are going
to have to respond to a smaller economy, probably gradually, and then suddenly when the 
musical
chairs financial situation ends up having 
12:30
too many people versus the amount of chairs
available. And that I think is in the next five to seven
years. And so this means that our regenerative agriculture
and our low carbon technologies and our 50 to 100 year solar panel yet to come inventions
and our communities having more local and regional supply chains and all the things
that would benefit a reduced emission economy 
13:00
are not going to happen directly. Nate Hagens:
They need to be happening in tandem, in parallel with this other story that's unfolding. And 
I think there's too few people in the
climate community that are paying attention to this sort of a flow chart of the future. And 
that doesn't mean that we shouldn't stop
caring about climate change or other species or the natural world. 
13:30
It just means to understand that the way the
game pieces are moving, we are not going to collectively galvanize around this problem
because finance, the economy and an increase in poverty to lots more people in the world
are going to take precedence. Nate Hagens:
So this is kind of how I see the seven stages of climate awareness. At least, that's how I 
have kind of moved
through them in my personal and professional 
7 / 8
14:00
life. I still care deeply about climate change and
biodiversity, but I'm trying to work looking two or three steps ahead on what the interventions
that we really need to be doing to save all these things and future reflections on this
show and podcast guests will be discussing those. Thank you. Have a good weekend. I will 
talk to you next week. 
8 / 8