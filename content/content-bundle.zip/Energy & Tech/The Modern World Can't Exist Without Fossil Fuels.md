tags: #🗃/🟥️ 
aliases: 
ref: 
https://time.com/6175734/reliance-on-fossil-fuels/

---
- Modern society can't exist without 4 ingredients:
  1. Ammonia (fertilizer)
  2. Plastics (computers, health care products)
  3. Steel (skyscrapers, bridges, cars, scalpels)
  4. Cement (buildings, roads, dams, runways)
  They all require fossil fuels.
  