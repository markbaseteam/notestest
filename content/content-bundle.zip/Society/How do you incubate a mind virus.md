tags: #🗃/🟨 
aliases: 
ref: 
https://twitter.com/bfcarlson/status/1596146675021762562

---
## Highlights
- How do you incubate a mind virus? How do you cause a culture to self-destruct? 
  In 1984, this KGB defector exposed the secret 4-stage plan used by Soviet intelligence to wage psychological war on American society. 

- Stage 1: Demoralization. (15-20 years) 
	- 85% of KGB action was not spying, but ideological warfare. 
	  The aim was to change Americans' perception of reality so that "no one is able to come to sensible conclusions."
	  This loss of reality then weakens the family, community, country—and the self.
	- "A person who was demoralized is unable to assess true information. The facts tell nothing to him. ... 
	  When a military boot crushes his balls, then he will understand. But not before that." 

- Stage 2: Destabilization (2-5 years)
	  Once a society is demoralized, its weakness and unwillingness to defend itself is exploited to undermine the military, economy & foreign affairs. 

- Stage 3-4: Crisis & Normalization (6 weeks)
	  A weakened society is easily brought to crisis, causing a "violent change of power, structure, and economy." 
	  A benevolent dictator who makes grandiose promises could then be installed to bring things back to "normal."
	- In 1984, KGB defector Bezmenov warned the demoralization of the US was nearly complete.
	  After the final crisis, all those who helped in subversion will have no further use, he adds. "They will be lined up against the wall and shot." 
	- If Americans fail to grasp the impending danger, he said, "nothing ever can help the United States." 
	  “You may kiss goodbye to your freedom.”
	- Bezmenov died in 1993 in obscurity in Canada, where he lived under the assumed name Tomas Schuman. 
	  He considered himself a prophet but felt his warnings were ignored.
	  In an era of daily psychological war, his lessons have more to teach us today than ever. 
	  ![](https://pbs.twimg.com/media/Fiapg37XoAA4VTz.jpg) 
